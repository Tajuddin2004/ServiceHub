<?php
$host = "sql300.infinityfree.com";
$user = "if0_40863133";
$pass = "D6N2g7TbaImM";
$db   = "if0_40863133_tazx_db";

$conn = mysqli_connect($host, $user, $pass, $db);

if (!$conn) {
    die("Database connection failed: " . mysqli_connect_error());
}
